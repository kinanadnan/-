<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ختمة القرآن الكريم</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>ختمة القرآن الكريم</h1>

    <?php
    $quran_parts = [
        1 => 'الفاتحة والبقرة',
        2 => 'آل عمران والنساء',
        3 => 'المائدة والأنعام',
        4 => 'الأعراف والأنفال',
        5 => 'التوبة ويونس',
        6 => 'هود ويوسف',
        7 => 'الرعد وإبراهيم',
        8 => 'الحجر والنحل',
        9 => 'الإسراء والكهف',
        10 => 'مريم وطه',
        11 => 'الأنبياء والحج',
        12 => 'المؤمنون والنور',
        13 => 'الفرقان والشعراء',
        14 => 'النمل والقصص',
        15 => 'العنكبوت والروم',
        16 => 'لقمان والسجدة',
        17 => 'الأحزاب والسبأ',
        18 => 'فاطر ويس',
        19 => 'الصافات وص',
        20 => 'الدخان والجاثية',
        21 => 'الأحقاف ومحمد',
        22 => 'الفتح والحجرات',
        23 => 'ق والدخان',
        24 => 'الجاثية والأحقاف',
        25 => 'محمد والفتح',
        26 => 'الحجرات والزلزلة',
        27 => 'الملك والقلم',
        28 => 'الحاقة والمعارج',
        29 => 'نوح والجن',
        30 => 'المدثر والقيامة'
    ];

    $booked_parts = [];
    if (file_exists('booked_parts.json')) {
        $booked_parts = json_decode(file_get_contents('booked_parts.json'), true);
    }

    if (isset($_GET['book'])) {
        $booked_part = (int)$_GET['book'];
        if (!in_array($booked_part, $booked_parts)) {
            $booked_parts[] = $booked_part;
            file_put_contents('booked_parts.json', json_encode($booked_parts));
        }
    }

    foreach ($quran_parts as $part => $name) {
        $isBooked = in_array($part, $booked_parts);
        echo "<div class='section'>";
        echo "<h2>الجزء $part: $name</h2>";
        if ($isBooked) {
            echo "<p class='booked'>محجوز</p>";
        } else {
            echo "<p class='available'>متاح للحجز</p>";
            echo "<a href='?book=$part' class='btn'>حجز</a>";
        }
        echo "</div>";
    }
    ?>
</body>
</html>
